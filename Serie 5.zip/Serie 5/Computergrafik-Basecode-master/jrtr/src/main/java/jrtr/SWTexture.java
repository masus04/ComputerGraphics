package jrtr;

import java.io.IOException;

/**
 * Manages textures for the software renderer. Not implemented here.
 */
public class SWTexture implements Texture {

	public void load(String fileName) throws IOException {
	}

}
