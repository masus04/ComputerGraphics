package jrtr;

/**
 * A simple implementation of {@link VertexData} which does not add any
 * additional functionality.
 */
public class SWVertexData extends VertexData {

	public SWVertexData(int n) {
		super(n);
	}
}
